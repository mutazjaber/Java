package snippet;

public class Snippet {
	<c:out value="${Message}"></c:out>
}

